$(function () {
    // View model to handle properties and actions of term application.
    javascriptTest = (function () {
        // Constructor for javascriptTest view model.
        var obj = function () {
            var self = this;

            // Holds the list of terms.
            self.listOfTerms = ko.observableArray([]);

            // Holds the list of possible term types.
            self.listOfTermTypes = ko.observableArray([{ termTypeName: "Positive", termTypeId: 1 },
                                                       { termTypeName: "Negative", termTypeId: 2 }]);

            // Holds the current term which user is about to add.
            self.currentTerm = new termViewModel();

            // Add terms to list of terms after validation.
            self.addTerm = function () {
                // Validate terms form and add if the form is valid.
                if (self.isValid()) {
                    // Constructing new object to push in to the list of terms.
                    var currentTerm = new termViewModel();
                    currentTerm.termName(self.currentTerm.termName());
                    currentTerm.termType(self.currentTerm.termType());
                    self.listOfTerms.push(currentTerm);

                    // Sort list of terms array alphabetically based on term name.
                    self.listOfTerms.sort(function (first, second) { return first.termName() > second.termName() });

                    // Clear term form after adding.
                    self.currentTerm.termName("");
                    self.currentTerm.termType(0);
                    $("#termType").val(0);
                }
            };

            // Adds validator and validates term form.
            self.isValid = function () {
                // Add validator to term form
                $("#termFrom").validate({
                    errorElement: "span",
                    rules: {
                        TermType: { required: true },
                        Term: { required: true }
                    },
                    messages: {
                        TermType: { required: "This field is required." },
                        Term: { required: "This field is required." }
                    }
                });

                // Validate the form and return a flag that specifies whether or not the form is valid.
                return $("#termFrom").valid();
            };

            // Event handler for delete term button for each terms
            // Removes terms form list of terms.
            self.deleteTerm = function (data) {
                self.listOfTerms.remove(data);
            };

            // Event handler for select term from list of terms
            // Fills the term form with selected term data.
            self.selectTerm = function (data) {
                self.currentTerm.termName(data.termName());
                self.currentTerm.termType(data.termType());
                $("#termType").val(data.termType());
            };

            // Initializes the view model by binding the view model to the view.
            self.init = function () {
                var $javascriptTest = $('#javascriptTest');

                // Check if the view is present and it is not already bound.
                if ($javascriptTest.length != 0 && !ko.dataFor($javascriptTest.get(0))) {
                    ko.applyBindings(self, $javascriptTest.get(0));
                }
            };
        };

        return obj;
    })();

    // Create new object when page is loaded and initialize the view model.
    var javascriptTest = new javascriptTest();
    javascriptTest.init();
});