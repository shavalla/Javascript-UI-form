$(function () {
    // View model for term entity.
    termViewModel = (function () {
        // Constructor for termViewModel.
        var obj = function () {
            var self = this;

            // Gets or sets term name.
            self.termName = ko.observable("");

            // Gets or sets term type.
            self.termType = ko.observable(0);
        };
        return obj;
    })();
});